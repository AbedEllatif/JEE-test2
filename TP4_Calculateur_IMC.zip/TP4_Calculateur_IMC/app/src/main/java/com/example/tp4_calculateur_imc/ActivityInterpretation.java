package com.example.tp4_calculateur_imc;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityInterpretation extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activityinterpretation);

        TextView txtResult = findViewById(R.id.textResultinter);

        double imc = getIntent().getDoubleExtra("imc", 0);
        String categorie = getIntent().getStringExtra("categorie");

        txtResult.setText(String.format("Votre IMC : %.1f\n%s", imc, categorie));

        if (categorie.equals("Insuffisance pondérale")) {
            txtResult.setTextColor(Color.YELLOW);
        } else if (categorie.equals("Poids normal")) {
            txtResult.setTextColor(Color.GREEN);
        } else if (categorie.equals("Surpoids")) {
            txtResult.setTextColor(Color.parseColor("#FFA500"));
        } else {
            txtResult.setTextColor(Color.RED);
        }
    }
}
