package com.example.tp4_calculateur_imc;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private SeekBar seekPoids, seekTaille;
    private TextView txtPoidsLabel, txtTailleLabel, textResult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        seekPoids = findViewById(R.id.seekPoids);
        seekTaille = findViewById(R.id.seekTaille);
        txtPoidsLabel = findViewById(R.id.Textpoids);
        txtTailleLabel = findViewById(R.id.Texttaille);
        textResult = findViewById(R.id.textResult);
        Button btnCalculer = findViewById(R.id.btnCalculer);


            seekPoids.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int value, boolean fromUser) {
                    txtPoidsLabel.setText("Poids : " + value + " kg");
                    if (value < 40) {
                        txtPoidsLabel.setTextColor(Color.YELLOW);
                    } else if (value > 120) {
                        txtPoidsLabel.setTextColor(Color.RED);
                    } else {
                        txtPoidsLabel.setTextColor(Color.GREEN);
                    }
                }

                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) {}
            });


            seekTaille.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int value, boolean fromUser) {
                    txtTailleLabel.setText("Taille : " + value + " cm");
                }

                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) {}
            });

        btnCalculer.setOnClickListener(v -> {
            double poids = seekPoids.getProgress();
            double tailleCm = seekTaille.getProgress();
            double tailleM = tailleCm / 100.0;

            double imc = poids / (tailleM * tailleM);
            String categorie;

            if (imc < 18.5) {
                categorie = "Insuffisance pondérale";
                textResult.setTextColor(Color.YELLOW);
            } else if (imc < 25) {
                categorie = "Poids normal";
                textResult.setTextColor(Color.GREEN);
            } else if (imc < 30) {
                categorie = "Surpoids";
                textResult.setTextColor(Color.parseColor("#FFA500")); // orange
            } else {
                categorie = "Obésité";
                textResult.setTextColor(Color.RED);
            }

            Intent I = new Intent(MainActivity.this, ActivityInterpretation.class);
            I.putExtra("imc", imc);
            I.putExtra("categorie", categorie);
            startActivity(I);

            textResult.setText(String.format("IMC: %.1f\n%s", imc, categorie));});
    }
}